export const adminLinks = [
    { path: "/products", title: "Productos" },
    { path: "/orders", title: "Ordenes" },
    { path: "/users", title: "Usuarios" },
    { path: "/colors", title: "Colores" }
  ];
  