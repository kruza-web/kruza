export type StockStatus = {
  productId: number
  soldOut: boolean
  totalStock: number
}
